import javax.swing.*;

public class DiscotecaApp {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ClubFrame clubFrame = new ClubFrame();
            clubFrame.setVisible(true);
        });

    }
}